<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$root = (isset($_SERVER['HTTPS']) ? "https://" : "http://") . $_SERVER['HTTP_HOST'];
$root .= str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
$config['domain'] = $root;

$config['lisans_key'] = 'tHaG5pah6Ap79CRFvjMdWiTQt';