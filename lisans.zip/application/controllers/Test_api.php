<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Test_api extends CI_Controller
{
    

  public function index()
  {
    $apiURL = 'http://localhost/lisans/api/connectServer';

    $client = curl_init($apiURL);
    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($client);
    curl_close($client);

    $result = json_decode($response);

    var_dump($result);


    #$this->load->view('api_view');
  }

  public function deneme()
  {
    
  }


}

