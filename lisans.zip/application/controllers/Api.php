<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Api extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->config('lisans');
    }

    public function index()
    {
        $data = $this->api_model->getLisans();
        echo json_encode($data);
    }



    public function connectServer()
    {
        $lisans = $this->input->post('lisans');
        $domain = $this->input->post('domain');
        if ($lisans && $domain) {
            $getLisans = $this->api_model->getPrivateLisans($lisans, $domain);
            if ($getLisans[0] == 1) {
                $condition =  time() - strtotime($getLisans['info']->expirationTime);
                if($condition < 0){
                    echo "1"; // Lisans Geçerli
                }else{
                    echo "2"; // Lisans'ın Kullanım Süresi Sona Ermiş
                }
            } else {
                echo "3"; // Lisans Geçersiz
            }
        }else{
            echo "4"; // Lisans anahtarı veya domain'e ulaşılamadığından servera bağlanamadı
        }
    }
}
