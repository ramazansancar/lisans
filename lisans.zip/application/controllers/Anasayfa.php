<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Anasayfa extends CI_Controller
{

	public function index()
	{
		$this->load->view('index');
	}

	public function lisans_ekle()
	{
		$this->load->view('lisans_ekle');
	}

	public function add_license()
	{
		$domain = $this->input->post('domain');
		$exp_time = $this->input->post('exp_time');
		if ($domain && $exp_time) {
			$convertDate = date('Y-m-d', strtotime($exp_time));
			$key = sha1(rand(0, 1000));
			$data = array(
				'domain' => $domain,
				'key' => $key,
				'status' => 1,
				'createdAt' => date('Y-m-d H:i:s'),
				'expirationTime' => $convertDate
			);
			$insert = $this->api_model->add_license($data);
			if ($insert) {
				$alert = array(
					'text' => 'Girdiğiniz domaine lisans tanımlandı.',
					'type' => 'success'
				);
			} else {
				$alert = array(
					'text' => 'Opps! Teknik bir hata oluştu.',
					'type' => 'error'
				);
			}
		} else {
			$alert = array(
				'text' => 'Lütfen boş alan bırakmayınız.',
				'type' => 'info'
			);
		}
		$this->session->set_flashdata("alert", $alert);
		redirect(base_url('anasayfa/lisans_ekle'));
	}

	public function lisanslar()
	{
		$data = array(
			'lisanslar' => $this->api_model->getAll()
		);
		$this->load->view('lisanslar', $data);
	}

	public function lisans_getir()
	{
		if (isset($_POST["lisans_id"])) {
			$lisans = $this->api_model->getPrivate_License($this->input->post('lisans_id'));
			echo json_encode($lisans);
		}
	}

	public function lisans_guncelle()
	{
		$lisans_id = $this->input->post('lisans_id');
		$domain = $this->input->post('domain');
		$datemask = $this->input->post('time');
		$val = $this->input->post('exp_time');
		$status = $this->input->post('status');
		if (empty($datemask)) {
			$data = array(
				'domain' => $domain,
				'expirationTime' => $val,
				'status' => ($this->input->post("status") == "on")
			);
		} else {
			$data = array(
				'domain' => $domain,
				'expirationTime' => date("Y-m-d H:i:s", strtotime($datemask)),
				'status' => ($this->input->post("status") == "on")
			);
		}

		$update = $this->api_model->updateLicense($lisans_id, $data);

		if ($update) {
			$alert = array(
				'text' => 'Lisans başarıyla güncellendi.',
				'type' => 'success'
			);
		} else {
			$alert = array(
				'text' => 'Opps! Teknik bir hata oluştu.',
				'type' => 'error'
			);
		}

		$this->session->set_flashdata("alert", $alert);
		redirect(base_url('anasayfa/lisanslar'));
	}

	public function lisans_sil($id)
	{
		$delete = $this->api_model->deleteLicense($id);
		if ($delete) {
			$alert = array(
				'text' => 'Lisans başarıyla silindi.',
				'type' => 'success'
			);
		} else {
			$alert = array(
				'text' => 'Opps! Teknik bir hata oluştu.',
				'type' => 'error'
			);
		}

		$this->session->set_flashdata("alert", $alert);
		redirect(base_url('anasayfa/lisanslar'));
	}

	public function dokumantasyon()
	{
		$this->load->view('dokumantasyon');
	}
}
