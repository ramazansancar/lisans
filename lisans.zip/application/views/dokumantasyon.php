<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Lisanslar</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $this->load->view('inc/_css'); ?>
</head>

<body class="hold-transition sidebar-mini">
    <!-- Site wrapper -->
    <div class="wrapper">
        <!-- Navbar -->
        <?php $this->load->view('inc/_navbar'); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">

            <!-- Sidebar -->
            <?php $this->load->view('inc/_sidebar'); ?>
            <!-- /.sidebar -->
        </aside>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Dökümantasyon</h1>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="callout callout-info">
                                <h5><i class="fas fa-info"></i> Kurulum:</h5>
                                Aşağıdaki adımları takip ederek scriptinizi lisanslayabilirsiniz.
                            </div>


                            <!-- Main content -->
                            <div class="invoice p-3 mb-3">
                                <!-- title row -->
                                <div class="row">
                                    <div class="col-12">
                                        <h4>
                                            <i class="fas fa-globe"></i> Lisans Scripti v1
                                            <small class="float-right">Date: 2/10/2014</small>
                                        </h4>
                                    </div>
                                    <!-- /.col -->
                                </div>
                                <!-- info row -->
                                <div class="row invoice-info">
                                    <div class="col-sm-4 invoice-col">
                                        <address>
                                            <strong>1. Adım</strong><br>
                                            Öncelikle lisans menüsünden lisans ekleye gelerek<br>
                                            lisanslamak istediğiniz alan adını giriniz.<br>
                                            Örn : http://google.com/<br>
                                            Not: alan adının sonuna '/' işaretini mutlaka koyunuz.<br>
                                        </address>
                                    </div>
                                    <!-- /.col -->
                                    <div class="col-sm-4 invoice-col">
                                        <address>
                                            <strong>2. Adım</strong><br>
                                            Daha sonra lisanslar kısmına gelerek alan adına tanımlı<br>
                                            oluşturulan lisans anahtarını lisanslamak istediğiniz yazılımda<br>
                                            application/config/ klasörüne gelerek client/lisans.php <br>
                                            dosyasını atınız ve ilgili alana lisans anahtarını yapıştırınız.<br>
                                            application/core/ klasorüne client/MY_Controller.php dosyasını atın<br>
                                        </address>
                                    </div>
                                    
                                    <div class="col-sm-4 invoice-col">
                                        <address>
                                            <strong>3. Adım</strong><br>
                                            MY_Controller.php dosyasını açın ve $apiURL değişkenine<br>
                                            lisans sunucunuzun adresini yazınız.<br>
                                            Daha sonra client/Errors.php dosyasını<br>
                                            application/controllers/ klasörüne atın.<br>
                                        </address>
                                    </div>

                                    <div class="col-sm-4 invoice-col">
                                        <address>
                                            <strong>4. Adım</strong><br>
                                            Ardından application/config/routes.php<br>
                                            dosyasını açın ve $route['error/(:any)'] = 'errors/error/$1';<br>
                                            kodunu yapıştırın. Daha sonra client/errors klasörünü<br>
                                            application/views dizinine atın.
                                        </address>
                                    </div>

                                    
                                    <div class="col-sm-4 invoice-col">
                                        <address>
                                            <strong>5. Adım</strong><br>
                                            Sizin oluşturduğunuz controller dosyalarına extends CI_Controller<br>
                                            yerine extends MY_Controller yazınız. Tüm işlemler bu kadar. MY_Controller'ı<br>
                                            bir şifrelere programı ile şifrelemeyi unutmayınız.
                                        </address>
                                    </div>

                                    <!-- /.col -->
                                </div>
                                <!-- /.row -->

                            </div>
                            <!-- /.invoice -->
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
        <?php $this->load->view('inc/_footer'); ?>

    </div>
    <!-- ./wrapper -->

    <?php $this->load->view('inc/_js');  ?>
    <?php $this->load->view('alert'); ?>
</body>

</html>