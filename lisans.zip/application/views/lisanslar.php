<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Lisanslar</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $this->load->view('inc/_css'); ?>
</head>

<body class="hold-transition sidebar-mini">
    <!-- Site wrapper -->
    <div class="wrapper">
        <!-- Navbar -->
        <?php $this->load->view('inc/_navbar'); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">

            <!-- Sidebar -->
            <?php $this->load->view('inc/_sidebar'); ?>
            <!-- /.sidebar -->
        </aside>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Lisans Ekle</h1>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Tanımladığınız lisansları buradan görüntüleyebilir ve güncelleyebilirsiniz.</h3>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body table-responsive">
                                <table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Domain</th>
                                            <th>Lisans</th>
                                            <th>Durumu</th>
                                            <th>Başlangıç Tarihi</th>
                                            <th>Bitiş Tarihi</th>
                                            <th>İşlem</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($lisanslar as $lisans) : ?>
                                            <tr>
                                                <td><?= $lisans->domain; ?></td>
                                                <td><?= $lisans->key; ?></td>
                                                <td><?php $kosul = time() - strtotime($lisans->expirationTime);  if ($lisans->status == 1 && $kosul < 0) : echo '<span class="badge badge-pill badge-success">Aktif</span>';
                                                    else : echo '<span class="badge badge-pill badge-danger">Pasif</span>';
                                                    endif; ?></td>
                                                <td><?= date('d/m/Y', strtotime($lisans->createdAt)); ?></td>
                                                <td><?= date('d/m/Y', strtotime($lisans->expirationTime)); ?></td>
                                                <td>
                                                    <a id="<?= $lisans->id; ?>" class="btn btn-info edit" data-toggle="modal" data-target="#modal-default"><i class="fa fa-edit" style="color: #ffffff;"></i></a>
                                                    <a href="<?= base_url('anasayfa/lisans_sil/'.$lisans->id); ?>" class="btn btn-danger"><i class="fa fa-trash" style="color: #ffffff;"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>Domain</th>
                                            <th>Lisans</th>
                                            <th>Durumu</th>
                                            <th>Başlangıç Tarihi</th>
                                            <th>Bitiş Tarihi</th>
                                            <th>İşlem</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->


                    </div>
                    <!-- /.col -->
                </div>
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
        <div class="modal fade" id="modal-default">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Lisans Düzenleme</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?= base_url('anasayfa/lisans_guncelle'); ?>" method="POST">
                            <div class="form-group">
                                <label for="domain">Domain</label>
                                <input type="hidden" id="lisans_id" name="lisans_id">
                                <input type="hidden" id="exp_time"  name="exp_time">
                                <input type="text" class="form-control" id="domain" name="domain" placeholder="http://google.com/">
                            </div>
                            <div class="form-group">
                                <label for="domain">Lisansın Bitiş Tarihi (Güncellemeyecekseniz Boş Kalabilir)</label>
                                <input type="text" class="form-control" id="datemask" name="time" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy/mm/dd" data-mask>
                            </div>
                            <div class="form-group">
                                <div class="custom-control custom-checkbox">
                                    <input class="custom-control-input" type="checkbox" id="status" name="status">
                                    <label for="status" class="custom-control-label">Lisans Durumu</label>
                                </div>
                            </div>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="submit" class="btn btn-primary">Güncelle</button>
                    </div>
                    </form>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>

        <?php $this->load->view('inc/_footer'); ?>

    </div>
    <!-- ./wrapper -->

    <?php $this->load->view('inc/_js');  ?>
    <script>
        $(function() {

            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
            });
            
            //Datemask dd/mm/yyyy
            $('#datemask').inputmask('yyyy-mm-dd', { 'placeholder': 'yyyy/mm/dd' });


            $(document).on('click', '.edit', function() {
                var lisans_id = $(this).attr("id");
                $.ajax({
                    url: "<?= base_url('anasayfa/lisans_getir'); ?>",
                    type: "POST",
                    data: {
                        lisans_id: lisans_id
                    },
                    dataType: "json",
                    
                    success: function(resp) {
                        $("#lisans_id").val(resp.id);
                        $("#domain").val(resp.domain);
                        $("#exp_time").val(resp.expirationTime);

                        if (resp.status == 1) {
                            $('#status').prop('checked', true);
                        } else {
                            $('#status').prop('checked', false);
                        }

                        $("#modal-default").modal('show');
                    }
                });
            });


        })
    </script>
    <?php $this->load->view('alert'); ?>
</body>

</html>