<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Anasayfa</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php $this->load->view('inc/_css'); ?>
</head>

<body class="hold-transition sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">
    <!-- Navbar -->
    <?php $this->load->view('inc/_navbar'); ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
      <!-- Sidebar -->
      <?php $this->load->view('inc/_sidebar'); ?>
      <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Yönetim Paneli</h1>
            </div>
          </div>
        </div><!-- /.container-fluid -->
      </section>

      <!-- Main content -->
      <section class="content">

        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3><?= $this->db->get('lisans')->num_rows(); ?></h3>

                <p>Toplam Lisans</p>
              </div>
              <div class="icon">
                <i class="fas fa-hockey-puck"></i>
              </div>
              <a href="#" class="small-box-footer">Bilgilendirme <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?= $this->db->where('status', 1)->where('expirationTime >', date('Y-m-d'))->get('lisans')->num_rows(); ?></h3>
                <p>Aktif Lisans</p>
              </div>
              <div class="icon">
                <i class="fas fa-key"></i>
              </div>
              <a href="#" class="small-box-footer">Bilgilendirme <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3><?= $this->db->where('status', 0)->get('lisans')->num_rows(); ?></h3>
                <p>Pasif Lisanslar</p>
              </div>
              <div class="icon">
                <i class="fas fa-eye-slash"></i>
              </div>
              <a href="#" class="small-box-footer">Bilgilendirme <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?= $this->db->where('expirationTime <', date('Y-m-d'))->get('lisans')->num_rows(); ?></h3>
                <p>Kullanım Süresi Dolan Lisanslar</p>
              </div>
              <div class="icon">
                <i class="fas fa-hourglass"></i>
              </div>
              <a href="#" class="small-box-footer">Bilgilendirme <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>

          <!-- ./col -->
        </div>

      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <?php $this->load->view('inc/_footer'); ?>

  </div>
  <!-- ./wrapper -->

  <?php $this->load->view('inc/_js');  ?>
</body>

</html>