<?php $alert = $this->session->userdata("alert");
if ($alert) : ?>
    <script>
        $(function() {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000
            });
            Toast.fire({
                type: '<?= $alert['type']; ?>',
                title: '<?= $alert['text']; ?>'
            });
        });
    </script>
<?php endif; ?>