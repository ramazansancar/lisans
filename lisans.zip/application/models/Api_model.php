<?php
defined('BASEPATH') or exit('No direct script access allowed');


class Api_model extends CI_Model
{



  public function getLisans()
  {
    $this->db->order_by('id', 'DESC');
    return $this->db->get('lisans')->result();
  }

  public function getPrivateLisans($lisansKey, $domain)
  {
    $this->db->where('domain', $domain);
    $this->db->where('key', $lisansKey);
    $this->db->where('status', 1);
    $query = $this->db->get('lisans');
    if ($query->num_rows() > 0) {
      return array('1', 'info' => $query->row());
    } else {
      return 0;
    }
  }


  ///
  public function add_license($data)
  {
    return $this->db->insert('lisans', $data);
  }

  public function getAll()
  {
    return $this->db->get('lisans')->result();
  }

  public function getPrivate_License($id)
  {
    return $this->db->where('id', $id)->get('lisans')->row();
  }

  public function updateLicense($lisans_id, $data)
  {
    $update = $this->db->where('id', $lisans_id)->update('lisans', $data);
    return $update;
  }

  public function deleteLicense($id)
  {
    return $this->db->where('id', $id)->delete('lisans');
  }
}
