<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class MY_Controller extends CI_Controller{


    public function __construct()
    {
        parent::__construct();
        $this->load->config('lisans');

        $apiURL = 'http://localhost/lisans/api/connectServer';
        $data = array(
            'lisans' => $this->config->item('lisans_key'),
            'domain' => $this->config->item('domain')
        );

        $client = curl_init($apiURL);
        curl_setopt($client, CURLOPT_POST, true);
        curl_setopt($client, CURLOPT_POSTFIELDS, $data);
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($client);
        curl_close($client);
        if($response == 2){
            redirect(base_url('error/'.$response));
        }elseif($response == 3){
            redirect(base_url('error/'.$response));
        }elseif($response == 4){
            redirect(base_url('error/'.$response));
        }
    }

    
}