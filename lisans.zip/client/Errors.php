<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Errors extends CI_Controller {
    public function error($page)
    {
        if($page == 2){
            $title = 'Lisans Süresi Sona Erdi!';
            $response = "Lisansınız'ın kullanım süresi sona erdi.";
            $icon = '<i class="material-icons">hourglass_full</i>';
        }elseif($page == 3){
            $title = 'Geçersiz Lisans';
            $response = "Domain'e tanımlı lisans pasif hale getirilmiş veya lisans anahtarı ile domain eşleşmedi.";
            $icon = '<i class="material-icons">info</i>';
        }elseif($page == 4){
            $title = 'Hata';
            $response = "Sistem dosyalarına müdahale edildiği için sistem kapatıldı.";
            $icon = '<i class="material-icons">power_settings_new</i>';
        }
        $data = array(
            'title' => $title,
            'response' => $response,
            'icon' => $icon
        );

        $this->load->view('errors/error', $data);
    }
}
